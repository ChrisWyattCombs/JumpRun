package GameEngine;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.plaf.synth.ColorType;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Display {
    private boolean FP = false;
    private int VS = 0;
public JFrame Window;
public Boolean CloseRequested = false;
private boolean isInMidAir = false;
   public int orginX = 0;
    public int orginY = 0;
    private String levelDirectory = "Resources/levels/";
    private String levelName = "Level1/";
    private  String[] B = new String[10000];
    private int[] X = new int[10000];
    private  int[] Y = new int[10000];
    private  int[] FTB = new int[10000];
    private  int[] FTE = new int[10000];

    private File GrassTexture = new File("Resources/textures/blocks/grass.png");
    private  File DirtTexture = new File("Resources/textures/blocks/dirt.png");
    private  File PlayerTexture = new File("Resources/textures/entitys/Player.jpg");
    private BufferedImage grass = ImageIO.read(GrassTexture);
    private BufferedImage dirt = ImageIO.read(DirtTexture);
    private BufferedImage Player = ImageIO.read(PlayerTexture);
    private static boolean[] TFG = new boolean[10000];
    private static boolean[] TFD = new boolean[10000];
    public Display() throws IOException {
    }


    public void OpenDisplay(){
Window = new JFrame("2DPG");
Window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
loadLevel();

JPanel content = new JPanel(){

    public void paint(Graphics g) {
        if(orginY == 0){
        for(int i = 0; i < FTB.length; i++) {
            if (750-20> orginX + FTB[i] & 750 < orginX + FTE[i]) {
                FP = true;

            }
        }}
        g.drawImage(Player, 750, 150, Window);
        orginY += VS;
        if(orginY > 0 & !FP){
            VS--;

        }
        if(orginY == 0 & !FP){

            VS = 0;
            isInMidAir = false;


        }
        if(FP){
            VS--;
        }


    for(int i = 0; i < B.length; i++){

            if(TFG[i]) {
                g.drawImage(grass,orginX + X[i],orginY + Y[i], Window);

            }else if (TFD[i]){
                g.drawImage(dirt,orginX + X[i], orginY + Y[i], Window);

            }
        }




orginX-=10;





    }
};
content.setPreferredSize(new Dimension(1500, 750));
Window.getContentPane().add(content);
Window.pack();
Window.setVisible(true);
Window.setResizable(false);
Window.setBackground(new Color(135, 206,235));
        Window.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                CloseRequested = true;
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

        });
        Window.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {

            if(e.getKeyCode() == KeyEvent.VK_SPACE){
                if(!isInMidAir) {
                    isInMidAir = true;

                    VS += 10;
                }

            }
            }
        });

    }

    public void updateDisplay(){
int i = 0;
        this.Window.repaint();

    }

public void loadLevel(){
    File LB = new File(levelDirectory + levelName + "Level.block");
    File LX = new File(levelDirectory + levelName + "Level.x");
    File LY = new File(levelDirectory + levelName + "Level.y");
    File FB = new File(levelDirectory + levelName + "Level.ftb");
    File FE = new File(levelDirectory + levelName + "Level.fte");
    Scanner FR1 = null;
    try {
        FR1 = new Scanner(LB);
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }
    Scanner FR2 = null;
    try {
        FR2 = new Scanner(LX);
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }
    Scanner FR3 = null;
    try {
        FR3 = new Scanner(LY);
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }
    Scanner FR4 = null;
    try {
        FR4 = new Scanner(FB);
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }
    Scanner FR5 = null;
    try {
        FR5 = new Scanner(FE);
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }
    for(int x = 0; FR1.hasNextLine();){

        B[x] = FR1.nextLine();
        x++;
    }
    for(int x = 0; FR2.hasNextLine(); ){
        X[x] = Integer.parseInt(FR2.nextLine());
        x++;
    }
    for(int x = 0; FR3.hasNextLine(); ){
        Y[x] = Integer.parseInt(FR3.nextLine());
        x++;



    }
    for(int x = 0; FR4.hasNextLine(); ){
        FTB[x] = Integer.parseInt(FR4.nextLine());
        x++;



    }   for(int x = 0; FR5.hasNextLine(); ){
        FTE[x] = Integer.parseInt(FR5.nextLine());
        x++;



    }
    String g = "grass";
    String d = "dirt";
for(int i = 0; i < B.length; ){
    String block = B[i];
   if(g.equals(block)) {
       TFG[i] = true;
   }else  if(d.equals(block)) {
       TFD[i] = true;
   }
i++;
}
}
}



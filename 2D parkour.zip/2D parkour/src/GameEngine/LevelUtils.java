package GameEngine;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class LevelUtils {
private static String levelDirectory = "Resources/levels/";
private static String levelName = "level1/";
private static String[] B = new String[10000];
private static String[] X = new String[10000];
private static String[] Y = new String[10000];
private static File GrassTexture = new File("Resources/textures/blocks/grass.png");
private static File DirtTexture = new File("Resources/textures/blocks/dirt.png");


    private static boolean loaded = false;
    public static void load_and_draw_Level(Graphics g, ImageObserver IO) throws IOException {
        if(loaded = false) {
            File LB = new File(levelDirectory + levelName + "Level.block");
            File LX = new File(levelDirectory + levelName + "Level.X");
            File LY = new File(levelDirectory + levelName + "Level.Y");
            Scanner FR1 = new Scanner(LB);
            Scanner FR2 = new Scanner(LX);
            Scanner FR3 = new Scanner(LY);
            for(int x = 0; FR1.hasNextLine(); x++){
                B[x] = FR1.nextLine();
            }
            for(int x = 0; FR2.hasNextLine(); x++){
                X[x] = FR2.nextLine();
            }
            for(int x = 0; FR3.hasNextLine(); x++){
                Y[x] = FR3.nextLine();
            }
            loaded = true;

        }
        BufferedImage grass = ImageIO.read(GrassTexture);
        BufferedImage dirt = ImageIO.read(DirtTexture);
        for(int i = 0; i < B.length;i++){
            if(B[i].equals("grass")){
                g.drawImage(grass,Integer.parseInt(X[i]),Integer.parseInt(Y[i]), IO);
            }
            else if(B[i].equals("dirt")){
                g.drawImage(dirt,Integer.parseInt(X[i]),Integer.parseInt(Y[i]), IO);
            }
        }

    }
}
